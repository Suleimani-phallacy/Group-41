### Keyword quality report - All sources
**Overall rating: Good** (0% of the top-20 keywords flagged)

- Mean / median document coverage: 42% / 41%
- Bigram share: 0%   |   Redundancy: 0%
- Source-specific keywords (>80% of mentions in one source): 15%

**Observations**
- No systematic problems detected.

### Keyword quality report - nyt
**Overall rating: Fair** (35% of the top-20 keywords flagged)

- Mean / median document coverage: 22% / 20%
- Bigram share: 45%   |   Redundancy: 35%

**Observations**
- Many unigrams duplicate listed bigrams; consider de-duplicating for presentation.

**Flagged keywords**
- `index` - redundant with 'site index'
- `skip` - redundant with 'skip site'
- `site` - redundant with 'site index'
- `new` - redundant with 'new york'
- `york` - redundant with 'new york'
- `times` - redundant with 'york times'
- `today` - redundant with 'index today'

### Keyword quality report - wired
**Overall rating: Good** (0% of the top-20 keywords flagged)

- Mean / median document coverage: 56% / 60%
- Bigram share: 0%   |   Redundancy: 0%

**Observations**
- Keywords recur in most documents, i.e. they capture corpus-wide themes rather than page-specific details (expected for source-level keywords).

### Keyword quality report - toi
**Overall rating: Good** (0% of the top-20 keywords flagged)

- Mean / median document coverage: 36% / 34%
- Bigram share: 0%   |   Redundancy: 0%

**Observations**
- No systematic problems detected.